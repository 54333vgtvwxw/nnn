package com.example.autoplay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class AutoPlayService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val recognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val targets = listOf("PLAY AGAIN")

    private val intervalMs = 2000L
    private val cooldownMs = 6000L
    private var lastTap = 0L
    private var busy = false
    private var busySince = 0L
    private var toast: Toast? = null

    private fun say(msg: String) {
        handler.post {
            toast?.cancel()
            toast = Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT)
            toast?.show()
        }
    }

    private val loop = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            // защита от зависания флага busy
            if (busy && now - busySince > 8000) busy = false
            if (!busy && now - lastTap > cooldownMs) capture()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        say("AutoPlay: сервис запущен")
        handler.post(loop)
    }

    private fun capture() {
        busy = true
        busySince = System.currentTimeMillis()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        try {
                            val hw = result.hardwareBuffer
                            val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            hw.close()
                            if (bmp == null) {
                                say("AutoPlay: bitmap = null")
                                busy = false
                                return
                            }
                            recognize(bmp)
                        } catch (e: Exception) {
                            say("AutoPlay: ошибка " + e.message)
                            busy = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        say("AutoPlay: скриншот не удался, код $errorCode")
                        busy = false
                    }
                })
        } catch (e: Exception) {
            say("AutoPlay: исключение " + e.message)
            busy = false
        }
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val all = text.textBlocks.flatMap { it.lines }
                for (line in all) {
                    val t = line.text.uppercase().trim()
                    val box = line.boundingBox ?: continue
                    if (targets.any { t.contains(it) }) {
                        say("AutoPlay: нашёл «$t», нажимаю")
                        tap(box.centerX().toFloat(), box.centerY().toFloat())
                        return@addOnSuccessListener
                    }
                }
                val sample = all.joinToString(" | ") { it.text }.take(80)
                say("AutoPlay видит: " + if (sample.isEmpty()) "(текста нет)" else sample)
            }
            .addOnFailureListener { say("AutoPlay: ошибка OCR " + it.message) }
            .addOnCompleteListener { busy = false }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
        lastTap = System.currentTimeMillis()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}
